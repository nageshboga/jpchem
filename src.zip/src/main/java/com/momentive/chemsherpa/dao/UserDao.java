package com.momentive.chemsherpa.dao;

import java.util.List;

import com.momentive.chemsherpa.model.LogActivity;
import com.momentive.chemsherpa.model.Mail;
import com.momentive.chemsherpa.model.Register;
import com.momentive.chemsherpa.model.SearchUser;
import com.momentive.chemsherpa.model.User;


public interface UserDao {

	
	public User validateUserwithAzureDetails(String email);
	public boolean checkUserNameExistince(String userid) ;
	public boolean updateUser(User user);
	public boolean addUser(SearchUser user);
	public boolean registerUser(Register user);
	public List<LogActivity> searchUserLogActivity(String username);
	public void updateLogoutActivity(User user);
	public List<SearchUser> searchUsers(SearchUser search);
	public boolean updateSearchUser(SearchUser searchUser) ;
	public List<Mail> getRequestList() ;
	public Mail getRequestDetails(String reqNum);
	public SearchUser getsearchUserDetails(String username);
	public boolean logEmailActivity(Mail  mail);
	public void updateRequestDetails(Mail mail);
}
