package com.momentive.chemsherpa.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.momentive.chemsherpa.model.LogActivity;
import com.momentive.chemsherpa.model.Mail;
import com.momentive.chemsherpa.model.Register;
import com.momentive.chemsherpa.model.SearchUser;
import com.momentive.chemsherpa.model.User;
import com.momentive.chemsherpa.util.CryptoUtil;

public class UserDaoImpl implements UserDao {

	@Autowired
	DataSource datasource;
	@Autowired
	JdbcTemplate jdbcTemplate;

	public User validateUserwithAzureDetails(String email) {

		String sqlQuery = DBQueries.VALIDATE_USER;

		String args[] = { email };
		boolean validUser = false;

		java.util.List<User> users = jdbcTemplate.query(sqlQuery, args, new UserMapper());
		User user = users.size() > 0 ? users.get(0) : null;

		if (user.getEmail() != null)
			validUser = true;

		// if user is valid; update user last login time, get the max session id and
		// insert a new session record.
		if (validUser && user.getStatus() == 2) {

			jdbcTemplate.update(DBQueries.LAST_LOGIN_UPDATE, new java.sql.Timestamp(getjapanDateFormat().getTime()), user.getEmail().toUpperCase());

			List<Integer> maxSessionId = jdbcTemplate.query(DBQueries.GET_MAX_SESSION_ID, new GetMaxSessionId());

			jdbcTemplate.update(DBQueries.INSERT_USER_SESSION_LOG, user.getEmail(),
					new java.sql.Timestamp(getjapanDateFormat().getTime()), maxSessionId.get(0) + 1);
			user.setLoginSessionId(maxSessionId.get(0) + 1);
		}

		return user;
	}


	public boolean checkUserNameExistince(String userid) {

		String query = DBQueries.CHECK_USERNAME_EXISTS;
		String args[] = { userid };
		return jdbcTemplate.query(query, args, new CheckUserExistsMapper()).size() > 0 ? true : false;
	}

	public boolean updateUser(User user) {

		String query = DBQueries.UPDATE_USER;
		return jdbcTemplate.update(query, user.getFirstName(), user.getLastName(), user.getEmail(), user.getLangId(),
				user.getCompany(), user.getPhone(), new java.sql.Timestamp(getjapanDateFormat().getTime()),
				user.getDistNumber(), user.getUserSeq()) > 0 ? true : false;
	}

	public boolean addUser(SearchUser user) {

		String usrSeqQuery = DBQueries.GET_USR_SEQ_NUM;
		int userSeq = jdbcTemplate.query(usrSeqQuery, new UserSeqMapper()).get(0);
		String updateuserQuery = DBQueries.ADD_USER;

		return jdbcTemplate.update(updateuserQuery, userSeq + 1, user.getSearchUserFirstName(),
				user.getSearchUserLastName(), user.getSearchUserEmail(), user.getSearchUserLang(),
				user.getSeachusertype(), user.getSearchUserPhone(), user.getSearchUserCompany(),
				user.getSearchUserStatus(), user.getSearchUserDistNumber()) > 0 ? true : false;
	}

	public boolean registerUser(Register user) {

		String usrSeqQuery = DBQueries.GET_USR_SEQ_NUM;
		int userSeq = jdbcTemplate.query(usrSeqQuery, new UserSeqMapper()).get(0);
		String adduserQuery = DBQueries.ADD_USER;

		return jdbcTemplate.update(adduserQuery, userSeq + 1, user.getFirstName(), user.getLastName(), user.getEmail(),
				user.getLangId(), "Regular", user.getPhone(), user.getCompanyName(), "1", user.getDistNumber()) > 0
						? true
						: false;
	}

	public List<LogActivity> searchUserLogActivity(String username) {

		String sqlquery = DBQueries.SEARCH_USER_LOG_ACTIVITY;
		String args[] = { username };
		List<LogActivity> list = jdbcTemplate.query(sqlquery, args, new SearchUserLogActivityMapper());
		return list;
	}

	public void updateLogoutActivity(User user) {

		String query = DBQueries.UPDATE_LOGOUT_ACTIVITY;
		jdbcTemplate.update(query, new java.sql.Timestamp(getjapanDateFormat().getTime()), user.getLoginSessionId());
	}

	public List<SearchUser> searchUsers(SearchUser search) {

		String searchValue = search.getSearchBy();
		String query = DBQueries.SEARCH_USERS;
		if (searchValue != null && searchValue.equals("email")) 
			searchValue = "usr_email";
			
		query += searchValue + ") like upper('" + search.getSearchValue() + "')";
		System.out.println("final query:" + query);
		return jdbcTemplate.query(query, new SearchUserMapper());
	}

	public SearchUser getsearchUserDetails(String username) {

		String query = DBQueries.GET_SEARCH_USER_DETAILS;

		String args[] = { username };
		return jdbcTemplate.query(query, args, new SearchUserDetailsMapper()).get(0);
	}

	public boolean updateSearchUser(SearchUser searchUser) {

		String query = DBQueries.UPDATE_SEARCH_USER;

		return jdbcTemplate.update(query, searchUser.getSearchUserFirstName(), searchUser.getSearchUserLastName(),
				searchUser.getSearchUserEmail(), searchUser.getSearchUserLang(), searchUser.getSearchUserStatus(),
				searchUser.getSeachusertype(), new java.sql.Timestamp(getjapanDateFormat().getTime()),
				searchUser.getSearchUserCompany(), searchUser.getSearchUserPhone(),
				new java.sql.Timestamp(getjapanDateFormat().getTime()), searchUser.getSearchUserDistNumber(),
				searchUser.getSearchUserSeq()) > 0 ? true : false;
	}

	public boolean logEmailActivity(Mail mail) {

		String logEmailQuery = DBQueries.INSERT_LOG_REQUEST;
		String emailSeqQuery = DBQueries.GET_MAIL_SEQ_NUM;
		int mailSeq = jdbcTemplate.query(emailSeqQuery, new EmailSeqMapper()).get(0);
		return jdbcTemplate.update(logEmailQuery, mailSeq + 1, mail.getUseremail(),
				new java.sql.Timestamp(getjapanDateFormat().getTime()), mail.getSubject(), mail.getContent(),
				mail.getStatus(), mail.getType()) > 0 ? true : false;
	}

	public List<Mail> getRequestList() {

		String query = DBQueries.GET_REQUEST_LIST;

		return jdbcTemplate.query(query, new MailMapper());
	}

	public Mail getRequestDetails(String reqNum) {

		String query = DBQueries.GET_REQUEST_DETAILS;
		String args[] = { reqNum };
		java.util.List<Mail> mail = jdbcTemplate.query(query, args, new MailMapper());

		return mail.get(0);
	}

	public void updateRequestDetails(Mail mail) {

		String query = DBQueries.UPDATE_REQUEST;

		jdbcTemplate.update(query, mail.getStatus(), new java.sql.Timestamp(getjapanDateFormat().getTime()),
				mail.getMailSeqId());
	}

	private java.util.Date getjapanDateFormat() {

		Calendar localTime = Calendar.getInstance();
		Calendar japantime = new GregorianCalendar(TimeZone.getTimeZone("Japan"));
		japantime.setTimeInMillis(localTime.getTimeInMillis());

		int hour = japantime.get(Calendar.HOUR_OF_DAY);
		int minute = japantime.get(Calendar.MINUTE);
		int second = japantime.get(Calendar.SECOND);
		int month = japantime.get(Calendar.MONTH);
		int year = japantime.get(Calendar.YEAR);
		int day = japantime.get(Calendar.DATE);
		japantime.set(Calendar.YEAR, year);
		japantime.set(Calendar.MONTH, month);
		japantime.set(Calendar.DATE, day);
		japantime.set(Calendar.HOUR, hour);
		japantime.set(Calendar.MINUTE, minute);
		japantime.set(Calendar.SECOND, second);
		java.util.Date jpd = new Date(year - 1900, month, day, hour, minute, second);
		return jpd;
	}

}

class UserMapper implements RowMapper<User> {

	public User mapRow(ResultSet rs, int arg1) throws SQLException {

		User user = new User();

		user.setUserSeq(rs.getInt("usr_seq"));
		user.setFirstName(rs.getString("first_name"));
		user.setLastName(rs.getString("last_name"));
		user.setEmail(rs.getString("usr_email"));
		user.setPhone(rs.getString("phone"));
		user.setCompany(rs.getString("company"));
		String langid = rs.getString("langid");
		user.setLangId(langid == null ? langid = "en" : langid);
		user.setStatus(rs.getInt("status"));
		user.setLastLogin(rs.getTimestamp("last_login"));
		user.setLastUpdatedProfile(rs.getTimestamp("profile_updated_date"));
		user.setUserType(rs.getString("usr_type"));

		user.setDistNumber(rs.getString("dist_num"));
		return user;
	}
}

class SearchUserMapper implements RowMapper<SearchUser> {

	public SearchUser mapRow(ResultSet rsResponse, int arg1) throws SQLException {

		SearchUser user = new SearchUser();

		user.setSearchUserSeq(rsResponse.getInt("usr_seq"));

		user.setSearchUserFirstName(rsResponse.getString("first_name"));
		user.setSearchUserLastName(rsResponse.getString("last_name"));
		user.setSearchUserEmail(rsResponse.getString("usr_email"));
		user.setSearchUserStatus(rsResponse.getInt("status"));
		user.setSearchUserCompany(rsResponse.getString("company"));

		user.setSearchUserDistNumber(rsResponse.getString("dist_num"));
		return user;
	}
}

class SearchUserDetailsMapper implements RowMapper<SearchUser> {

	public SearchUser mapRow(ResultSet rsResponse, int arg1) throws SQLException {

		SearchUser user = new SearchUser();

		user.setSearchUserSeq(rsResponse.getInt("usr_seq"));

		user.setSearchUserFirstName(rsResponse.getString("first_name"));
		user.setSearchUserLastName(rsResponse.getString("last_name"));
		user.setSearchUserEmail(rsResponse.getString("usr_email"));
		user.setSearchUserStatus(rsResponse.getInt("status"));
		user.setSearchUserLang(rsResponse.getString("langId"));
		user.setSearchUserStatus(rsResponse.getInt("status"));
		user.setSearchUserCompany(rsResponse.getString("company"));
		user.setSearchUserPhone(rsResponse.getString("phone"));
		user.setSearchUserLastlogin(rsResponse.getDate("last_login"));
		user.setSeachusertype(rsResponse.getString("usr_type"));
		user.setSearchUserProfileUpdate(rsResponse.getTimestamp("profile_updated_date"));
		user.setSearchUserDistNumber(rsResponse.getString("dist_num"));
		return user;
	}
}

class SearchUserLogActivityMapper implements RowMapper<LogActivity> {

	public LogActivity mapRow(ResultSet rsResponse, int arg1) throws SQLException {

		LogActivity log = new LogActivity();

		log.setSessionid(rsResponse.getInt("session_id"));
		log.setLogin(rsResponse.getTimestamp("login_time"));
		log.setLogout(rsResponse.getTimestamp("logout_time"));

		return log;
	}
}

class PasswordMapper implements RowMapper<String> {

	public String mapRow(ResultSet rsResponse, int arg1) throws SQLException {

		String passwd = "";
		passwd += CryptoUtil.decrypt(rsResponse.getString("passwd")) + ";";
		passwd += rsResponse.getString("status") + ";";
		passwd += rsResponse.getString("wrong_pwd_attempts");

		return passwd;
	}
}

class UserSeqMapper implements RowMapper<Integer> {

	public Integer mapRow(ResultSet rsResponse, int arg1) throws SQLException {

		return rsResponse.getInt("usr_seq");
	}
}

class EmailSeqMapper implements RowMapper<Integer> {

	public Integer mapRow(ResultSet rsResponse, int arg1) throws SQLException {

		return rsResponse.getInt("seqnum");
	}
}

class CheckUserExistsMapper implements RowMapper<String> {

	public String mapRow(ResultSet rsResponse, int arg1) throws SQLException {

		return rsResponse.getString("usr_email");

	}
}

class MailMapper implements RowMapper<Mail> {

	public Mail mapRow(ResultSet rs, int arg1) throws SQLException {

		Mail mail = new Mail();
		mail.setMailSeqId(rs.getInt("seqnum"));
		mail.setUseremail(rs.getString("usr_email"));
		mail.setMailDate(rs.getTimestamp("emaildate"));
		mail.setUpdatedDate(rs.getTimestamp("updated_date"));
		mail.setSubject(rs.getString("subject"));
		mail.setContent(rs.getString("content"));
		mail.setStatus(rs.getString("status"));
		mail.setType(rs.getString("emailtype"));
		return mail;
	}
}

class UserExistMapper implements RowMapper<String> {

	public String mapRow(ResultSet rs, int arg1) throws SQLException {
		return rs.getString("se_logon");
	}
}

class GetMaxSessionId implements RowMapper<Integer> {

	public Integer mapRow(ResultSet rs, int arg1) throws SQLException {
		return rs.getInt("session_id");
	}
}