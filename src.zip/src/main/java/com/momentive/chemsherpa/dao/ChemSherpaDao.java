package com.momentive.chemsherpa.dao;

import java.util.List;

import com.momentive.chemsherpa.model.ChemSherpaSaleHistory;
import com.momentive.chemsherpa.model.UploadFile;
import com.momentive.chemsherpa.model.UsageReport;

public interface ChemSherpaDao {

	public List<ChemSherpaSaleHistory> getChemSherpaSaleHistory(String distnum);

	public boolean saveChemSherpaUsageHistory(UsageReport report);

	public List<UsageReport> getChemSherpaUsageHistory();
	
	public boolean saveUploadDocstoDB(UploadFile uploadFile);
	
	public UploadFile getMaterialDetails(String matnum);

}
