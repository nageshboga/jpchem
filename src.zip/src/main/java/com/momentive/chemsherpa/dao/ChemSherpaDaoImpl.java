package com.momentive.chemsherpa.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Optional;
import java.util.TimeZone;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.momentive.chemsherpa.model.ChemSherpaSaleHistory;
import com.momentive.chemsherpa.model.UploadFile;
import com.momentive.chemsherpa.model.UsageReport;
import com.momentive.chemsherpa.model.User;

public class ChemSherpaDaoImpl implements ChemSherpaDao {

	@Autowired
	DataSource datasource;
	@Autowired
	JdbcTemplate jdbcTemplate;

	public List<ChemSherpaSaleHistory> getChemSherpaSaleHistory(String distnum) {

		String query = DBQueries.GET_CHEMSPRA_SALES_HIST + " where custnum = '" + distnum + "'";

		java.util.List<ChemSherpaSaleHistory> ChemSherpasaleHistory = jdbcTemplate.query(query,
				new ChemSherpaSalesHistMapper());

		return ChemSherpasaleHistory;
	}

	public boolean saveChemSherpaUsageHistory(UsageReport report) {

		String usageSeqQuery = DBQueries.GET_CHEMSHERPA_USAGE_HIST_SEQ_NUM;
		int usageSeq = jdbcTemplate.query(usageSeqQuery, new UsageSeqMapper()).get(0);

		String addusageHistory = DBQueries.INSERT_CHEMSPRA_USAGE_HIST;

		return jdbcTemplate.update(addusageHistory, usageSeq + 1, report.getUserEmail(), 
				report.getMaterialNum(), report.getMaterialType(),
				new java.sql.Timestamp(getjapanDateFormat().getTime()), report.getFileName()) > 0 ? true : false;

	}

	public List<UsageReport> getChemSherpaUsageHistory() {

		String query = DBQueries.GET_CHEMSPRA_USAGE_HIST;

		java.util.List<UsageReport> chemSherpaSalesUsageMapper = jdbcTemplate.query(query,
				new ChemSherpaSalesUsageMapper());

		return chemSherpaSalesUsageMapper;
	}

	
	
	public boolean saveUploadDocstoDB(UploadFile uploadFile) {

		return jdbcTemplate.update(DBQueries.UPLOAD_DOCS_DETAILS_TO_DB, uploadFile.getSchifile1().getOriginalFilename(), uploadFile.getSchifile2().getOriginalFilename(),
				uploadFile.getVersion(), uploadFile.getMatType()
				, uploadFile.getMatNumber()) > 0 ? true : false;

	}

	public UploadFile getMaterialDetails(String matnum) {

		String query = DBQueries.GET_MATERIAL_DATA;
		String args[] = {matnum};
		
		java.util.List<UploadFile> matdetails = jdbcTemplate.query(query, args, new UploadFileMapper());
		UploadFile uploadFile =  matdetails.size() > 0 ? matdetails.get(0) : null;

		return uploadFile;
	}

	
	
	
	private java.util.Date getjapanDateFormat() {

		Calendar localTime = Calendar.getInstance();
		Calendar japantime = new GregorianCalendar(TimeZone.getTimeZone("Japan"));
		japantime.setTimeInMillis(localTime.getTimeInMillis());

		int hour = japantime.get(Calendar.HOUR_OF_DAY);
		int minute = japantime.get(Calendar.MINUTE);
		int second = japantime.get(Calendar.SECOND);
		int month = japantime.get(Calendar.MONTH);
		int year = japantime.get(Calendar.YEAR);
		int day = japantime.get(Calendar.DATE);
		japantime.set(Calendar.YEAR, year);
		japantime.set(Calendar.MONTH, month);
		japantime.set(Calendar.DATE, day);
		japantime.set(Calendar.HOUR, hour);
		japantime.set(Calendar.MINUTE, minute);
		japantime.set(Calendar.SECOND, second);
		java.util.Date jpd = new Date(year - 1900, month, day, hour, minute, second);
		return jpd;
	}
}

class ChemSherpaSalesHistMapper implements RowMapper<ChemSherpaSaleHistory> {

	public ChemSherpaSaleHistory mapRow(ResultSet rs, int arg1) throws SQLException {

		ChemSherpaSaleHistory saleshist = new ChemSherpaSaleHistory();
		saleshist.setCustomerNumber(rs.getString("custnum"));
		saleshist.setCustomerName(rs.getString("custname"));
		saleshist.setMatNumber(rs.getString("matnum"));
		saleshist.setMatName(rs.getString("matname"));
		saleshist.setMatnameb(rs.getString("matnameb"));
		saleshist.setSchifilename1(rs.getString("schifilename1"));
		saleshist.setSchifilename2(rs.getString("schifilename2"));
		saleshist.setMatType(rs.getString("mattype").trim());
		saleshist.setVersion(rs.getString("version_num"));
		return saleshist;
	}
}

class ChemSherpaSalesUsageMapper implements RowMapper<UsageReport> {

	public UsageReport mapRow(ResultSet rs, int arg1) throws SQLException {

		UsageReport report = new UsageReport();
		report.setReportId(rs.getInt("USAGEHIST_ID"));
		report.setUserEmail(rs.getString("USR_EMAIL"));
		report.setMaterialNum(rs.getInt("MATNUM"));
		report.setMaterialType(rs.getString("USAGETYPE"));
		report.setUsageTime(rs.getTimestamp("USAGETIME"));
		report.setFileName(rs.getString("FILE_NAME"));
		return report;
	}
}

class UsageSeqMapper implements RowMapper<Integer> {

	public Integer mapRow(ResultSet rsResponse, int arg1) throws SQLException {

		return rsResponse.getInt("usage_seq");
	}
}


class  UploadFileMapper implements RowMapper<UploadFile> {

	public UploadFile mapRow(ResultSet rsResponse, int arg1) throws SQLException {

		
 
		UploadFile file = new UploadFile();
		file.setMatNumber(rsResponse.getString("matnum"));
		file.setMatName(rsResponse.getString("matname"));
		file.setMatnameb(rsResponse.getString("matnameb"));
		file.setMatType(rsResponse.getString("mattype"));
		file.setVersion(rsResponse.getString("version_num"));
		
		return file;
	}
}