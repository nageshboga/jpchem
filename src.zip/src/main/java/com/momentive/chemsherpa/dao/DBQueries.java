package com.momentive.chemsherpa.dao;

public interface DBQueries {

	public static final String VALIDATE_USER = "select usr_seq, first_name, last_name, usr_email, langId, status,phone,company, last_login, profile_updated_date, usr_type, dist_num from "
			+ "CHEMSHERPA_USER where UPPER(usr_email) = UPPER(?)";

	public static final String LAST_LOGIN_UPDATE = "update CHEMSHERPA_USER set last_login=? where UPPER(usr_email) = UPPER(?)";

	public static final String GET_MAX_SESSION_ID = "select max(session_id) as session_id from CHEMSHERPA_USER_LOG";

	public static final String INSERT_USER_SESSION_LOG = "insert into  CHEMSHERPA_USER_LOG (usr_email,login_time,session_id) values (?,?,?) ";

	public static final String UPDATE_USER_STATUS = "update CHEMSHERPA_USER set status = ? where UPPER(usr_email)=UPPER(?)";
	
	public static final String UPDATE_LOGOUT_ACTIVITY = "update CHEMSHERPA_USER_LOG set logout_time = ? where session_id = ?";

	public static final String UPDATE_USER = "update CHEMSHERPA_USER set first_name=?, last_name=?,usr_email=?, langid=?, company=?, phone=?,profile_updated_date=?, dist_num=? where usr_seq = ?";

	public static final String ADD_USER = "insert into  CHEMSHERPA_USER(usr_seq,first_name,last_name,usr_email, langid ,usr_type,phone, company, status,dist_num) values (?,?,?,?,?,?,?,?,?,?)";
	
	public static final String CHECK_USERNAME_EXISTS = "select usr_email from  CHEMSHERPA_USER where UPPER(usr_email) = UPPER(?)";
	
	public static final String SEARCH_USERS = "select usr_seq,first_name, last_name,usr_email,company, status,dist_num from CHEMSHERPA_USER where upper(";
	
	public static final String GET_SEARCH_USER_DETAILS = "select usr_seq,first_name, last_name,usr_email,langId,phone,company, status, last_login,profile_updated_date,usr_type,dist_num  from  CHEMSHERPA_USER where upper(usr_email)=upper(?)";
	
	public static final String SEARCH_USER_LOG_ACTIVITY = "select session_id,login_time,logout_time from ( select session_id, login_time,logout_time, ROW_NUMBER() OVER (ORDER BY session_id desc) AS rn from CHEMSHERPA_USER_LOG where usr_email =?) q WHERE rn <= 10 ORDER BY session_id";

	public static final String UPDATE_SEARCH_USER = "update CHEMSHERPA_USER set first_name=?, last_name=?,usr_email=?, langid=? ,status=?,usr_type=?, profile_updated_date=?,company=?, phone=?,last_login=?,dist_num=? where usr_seq = ?";

	public static final String GET_REQUEST_LIST = " select seqnum, FIRST_NAME, LAST_NAME, m.usr_email, emaildate,subject,content,m.STATUS as status,emailtype,updated_date from CHEMSHERPA_EMAIL m, CHEMSHERPA_USER u " + 
			" where u.usr_email=m.usr_email  order by seqnum desc";
	
	public static final String GET_REQUEST_DETAILS = " select seqnum, FIRST_NAME, LAST_NAME, m.usr_email, emaildate,subject,content,m.STATUS as status,emailtype,updated_date   from CHEMSHERPA_EMAIL m, CHEMSHERPA_USER u " + 
			" where u.usr_email=m.usr_email  and seqnum=?";

	public static final String INSERT_LOG_REQUEST = "insert into  CHEMSHERPA_EMAIL(seqnum, usr_email, emaildate,subject,content,status,emailtype) values (?,?,?,?,?,?,?)";
	public static final String UPDATE_REQUEST = "UPDATE CHEMSHERPA_EMAIL SET status=?, UPDATED_DATE=? WHERE SEQNUM=?";

	public static final String GET_MAIL_SEQ_NUM = "select max(seqnum) as seqnum from CHEMSHERPA_EMAIL";

	public static final String GET_USR_SEQ_NUM = "select max(usr_seq) as usr_seq from CHEMSHERPA_USER";
	
	public static final String GET_CHEMSPRA_SALES_HIST = "select custnum,custname,matnum,matname,matnameb,schifilename1,schifilename2,mattype,version_num from chemsherpa_sales ";
	
	public static final String INSERT_CHEMSPRA_USAGE_HIST = "INSERT INTO CHEMSHERPA_USAGE_HIST(USAGEHIST_ID, usr_email,MATNUM, USAGETYPE, USAGETIME,FILE_NAME) VALUES(?,?,?,?,?,?)";
	
	public static final String GET_CHEMSPRA_USAGE_HIST = "SELECT USAGEHIST_ID, usr_email,MATNUM, USAGETYPE, USAGETIME,FILE_NAME FROM CHEMSHERPA_USAGE_HIST";
	
	public static final String GET_CHEMSHERPA_USAGE_HIST_SEQ_NUM = "select max(USAGEHIST_ID) as usage_seq from CHEMSHERPA_USAGE_HIST";
	
	public static final String UPLOAD_DOCS_DETAILS_TO_DB="UPDATE chemsherpa_sales SET schifilename1=?, schifilename2=?,version_num=?, mattype=? WHERE matnum=?" ;
	
	public static final String GET_MATERIAL_DATA = "Select top 1  matnum,matname,matnameb,mattype,version_num from chemsherpa_sales where matnum=?";
}