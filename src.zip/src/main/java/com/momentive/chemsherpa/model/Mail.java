package com.momentive.chemsherpa.model;

import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@ToString
public class Mail {
	
	private String username;
	private String from;
	private String to;
	private String subject;
	private String content;
	private String type;
	private String additionalInfo;
	private String useremail;
	private int mailSeqId;
	private Date mailDate;
	private Date updatedDate;
	private String status;
	private String clickedButton;
	private boolean communicateToUser;
	
}