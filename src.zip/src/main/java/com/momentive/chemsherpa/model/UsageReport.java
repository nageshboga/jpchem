package com.momentive.chemsherpa.model;

import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@ToString
public class UsageReport {
	
	private int reportId;
	private String userEmail;
	private int materialNum;
	private String materialName;
	private String materialType;
	private String version;
	private Date usageTime;
	private String fileName;
}
