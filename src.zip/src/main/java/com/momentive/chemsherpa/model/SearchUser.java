package com.momentive.chemsherpa.model;

import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
@Data
@NoArgsConstructor
@ToString
public class SearchUser {
	
	private String searchBy;
	private String searchValue;
	private int searchUserSeq;
	private String searchUserFirstName;
	private String searchUserLastName;
	private String searchUserEmail;
	private String searchUserLang;
	private int searchUserStatus;
	private Date searchUserLastlogin;
	private Date searchUserProfileUpdate;
	private String searchUserPhone;
	private String searchUserCompany;
	private String seachusertype;
	private String clickedButton;
	private String clickedId;
	private boolean communicateToUser;
	private String searchUserDistNumber;
		
}
