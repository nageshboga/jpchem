package com.momentive.chemsherpa.model;

import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@ToString
public class LogActivity {
	
	private Date login;
	private Date logout;
	private String email;
	private int sessionid;
	
}