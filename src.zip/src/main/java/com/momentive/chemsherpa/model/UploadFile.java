package com.momentive.chemsherpa.model;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@ToString
public class UploadFile {

	private String matNumber;
	private String matName;
	private String matnameb;
	private String matType;
	private String version;
	private MultipartFile schifile1;
	private MultipartFile schifile2;
	private String clickedButton;
}
