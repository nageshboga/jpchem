package com.momentive.chemsherpa.model;

import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@ToString
public class User {
	
	private int logCount;
	private String firstName;
	private String lastName;
	private String userType;
	private String email;
	private int loginSessionId;
	private String message;
	private boolean isValidLogin;
	private int status;
	private Date lastLogin;
	private Date lastUpdatedProfile;
	private int userSeq;
	private String langId;
	private String clickedButton;
	private String company;
	private String phone;
	private String distNumber;
	
}