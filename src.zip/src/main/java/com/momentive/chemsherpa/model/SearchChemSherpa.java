package com.momentive.chemsherpa.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@ToString
public class SearchChemSherpa {

	private String searchDistNum;
	private String chemsherpamatnum;
	private String chemsherpamat;
	private String chemsherpatype;

}
