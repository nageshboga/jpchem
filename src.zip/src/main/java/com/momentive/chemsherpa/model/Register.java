package com.momentive.chemsherpa.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@ToString
public class Register {
	
	private String firstName;
	private String lastName;
	private String email;
	private String phone;
	private String companyName;
	private String langId;
	private String clickedButton;
	private String distNumber;
}
