package com.momentive.chemsherpa.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ChemSherpaSaleHistory {
	
	private String customerNumber;
	private String customerName;
	private String matNumber;
	private String matName;
	private String matnameb;
	private String schifilename1;
	private String schifilename2;
	private String matType;
	private String version;
	
}
