package com.momentive.chemsherpa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.momentive.chemsherpa.dao.ChemSherpaDao;
import com.momentive.chemsherpa.model.ChemSherpaSaleHistory;
import com.momentive.chemsherpa.model.UploadFile;
import com.momentive.chemsherpa.model.UsageReport;

public class ChemSherpaServiceImpl implements ChemSherpaService {

	@Autowired
	ChemSherpaDao ChemSherpaDao;

	public List<ChemSherpaSaleHistory> getChemSherpaSaleHistory(String distnum) {

		return ChemSherpaDao.getChemSherpaSaleHistory(distnum);
	}

	@Override
	public boolean saveChemSherpaUsageHistory(UsageReport report) {
		return ChemSherpaDao.saveChemSherpaUsageHistory(report);
	}

	@Override
	public List<UsageReport> getChemSherpaUsageHistory() {
		return ChemSherpaDao.getChemSherpaUsageHistory();
	}

	@Override
	public boolean saveUploadDocstoDB(UploadFile uploadFile) {
		 
		return ChemSherpaDao.saveUploadDocstoDB(uploadFile);
	}
	
	
	public UploadFile getMaterialDetails(String matnum) {
		
		return ChemSherpaDao.getMaterialDetails(matnum);
	}

}
