package com.momentive.chemsherpa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.momentive.chemsherpa.dao.UserDao;
import com.momentive.chemsherpa.model.LogActivity;
import com.momentive.chemsherpa.model.Mail;
import com.momentive.chemsherpa.model.Register;
import com.momentive.chemsherpa.model.SearchUser;
import com.momentive.chemsherpa.model.User;

public class UserServiceImpl implements UserService {

	@Autowired
	UserDao userDao;

	
	public User validateUserwithAzureDetails(String email) {
		
		return userDao.validateUserwithAzureDetails(email);
	}
	
	
	public List<SearchUser> searchUsers(SearchUser search) {

		return userDao.searchUsers(search);
	}

	public List<Mail> getRequestList() {

		return userDao.getRequestList();
	}

	public Mail getRequestDetails(String reqNum) {

		return userDao.getRequestDetails(reqNum);
 	}

	public boolean checkUserNameExistince(String userid) {

		return userDao.checkUserNameExistince(userid);
	}

	public boolean updateUser(User user) {

		return userDao.updateUser(user);
	}

	public boolean addUser(SearchUser user) {

		return userDao.addUser(user);
	}

	public boolean registerUser(Register user) {

		return userDao.registerUser(user);
	}

	public List<LogActivity> searchUserLogActivity(String username) {

		return userDao.searchUserLogActivity(username);
	}

	public void updateLogoutActivity(User user) {

		userDao.updateLogoutActivity(user);

	}

	public boolean updateSearchUser(SearchUser searchUser) {

		return userDao.updateSearchUser(searchUser);
	}

	public SearchUser getsearchUserDetails(String username) {

		return userDao.getsearchUserDetails(username);
	}

	public boolean logEmailActivity(Mail mail) {

		return userDao.logEmailActivity(mail);
	}

	
	public void updateRequestDetails(Mail mail) {
		 
		userDao.updateRequestDetails(mail);
	}
	
	 
}