package com.momentive.chemsherpa.config;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.NoHandlerFoundException;
@RestController
@RestControllerAdvice
public class ExceptionResolver {



    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ModelAndView handleNoHandlerFoundException(NoHandlerFoundException ex) {
       
    	ModelAndView mv = new ModelAndView("404");
        return mv;
    }
    
//    @ResponseStatus(HttpStatus.FORBIDDEN)
//    public ModelAndView handleForbiddenException(NoHandlerFoundException ex) {
//       
//    	ModelAndView mv = new ModelAndView("404");
//    	System.out.println("FORBIDDEN HANDLE HERE.....................................................................................................................");
//        return mv;
//    }
}

