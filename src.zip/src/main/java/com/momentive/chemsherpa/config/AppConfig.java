package com.momentive.chemsherpa.config;

import java.util.Arrays;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.oauth2.client.endpoint.DefaultAuthorizationCodeTokenResponseClient;
import org.springframework.security.oauth2.client.endpoint.OAuth2AuthorizationCodeGrantRequest;
import org.springframework.security.oauth2.client.http.OAuth2ErrorResponseErrorHandler;
import org.springframework.security.oauth2.core.OAuth2AccessToken;
import org.springframework.security.oauth2.core.endpoint.OAuth2AccessTokenResponse;
import org.springframework.security.oauth2.core.http.converter.OAuth2AccessTokenResponseHttpMessageConverter;
import org.springframework.web.client.RestOperations;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

import com.momentive.chemsherpa.dao.ChemSherpaDao;
import com.momentive.chemsherpa.dao.ChemSherpaDaoImpl;
import com.momentive.chemsherpa.dao.UserDao;
import com.momentive.chemsherpa.dao.UserDaoImpl;
import com.momentive.chemsherpa.service.ChemSherpaService;
import com.momentive.chemsherpa.service.ChemSherpaServiceImpl;
import com.momentive.chemsherpa.service.UserService;
import com.momentive.chemsherpa.service.UserServiceImpl;

@Configuration
@EnableWebSecurity
public class AppConfig extends WebSecurityConfigurerAdapter {

	@Override
    protected void configure( HttpSecurity http ) throws Exception {
        http
        	.csrf().disable()
        	.authorizeRequests()
    		.antMatchers( "/css/**", "/js/**").permitAll()
            .antMatchers( "/oauth2/**", "/login/**" ).permitAll()
            .and()
            .oauth2Login()
            .tokenEndpoint().accessTokenResponseClient( this::getTokenResponse);
        
    }

	
    private OAuth2AccessTokenResponse getTokenResponse( OAuth2AuthorizationCodeGrantRequest authorizationGrantRequest ) {
        DefaultAuthorizationCodeTokenResponseClient client = new DefaultAuthorizationCodeTokenResponseClient();
        client.setRestOperations( restOperations() );
        return client.getTokenResponse( authorizationGrantRequest );
    }

    private RestOperations restOperations() {
        OAuth2AccessTokenResponseHttpMessageConverter converter = new OAuth2AccessTokenResponseHttpMessageConverter();
        converter.setTokenResponseConverter( getConverter() );
        RestTemplate restTemplate = new RestTemplate( Arrays.asList(
                new FormHttpMessageConverter(), converter ) );
        restTemplate.setErrorHandler( new OAuth2ErrorResponseErrorHandler() );
        return restTemplate;
    }

    private Converter< Map< String, String >, OAuth2AccessTokenResponse > getConverter() {
        return map -> OAuth2AccessTokenResponse.withToken( map.get( "id_token" ) )
                .tokenType( OAuth2AccessToken.TokenType.BEARER )
                .scopes( Set.of(map.get( "scope" )) )
                .expiresIn( Long.parseLong( map.get( "not_before" ) ) )
                .additionalParameters( Map.of("id_token", map.get( "id_token" )) )
                .build();
    }

	@Bean
	public ChemSherpaService chemSherpaService() {

		return new ChemSherpaServiceImpl();

	}

	@Bean
	public ChemSherpaDao chemSherpaDao() {

		return new ChemSherpaDaoImpl();

	}

	@Bean
	public UserDao userDao() {
		return new UserDaoImpl();
	}

	@Bean
	public UserService userService() {
		return new UserServiceImpl();
	}

	@Bean
	public LocaleResolver localeResolver() {
		final SessionLocaleResolver localeResolver = new SessionLocaleResolver();
		localeResolver.setDefaultLocale(new Locale("en", "US"));
		return localeResolver;
	}

}