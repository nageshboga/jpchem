package com.momentive.chemsherpa.config;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;

@Configuration
@Order(Ordered.HIGHEST_PRECEDENCE)
public class CustomFilter implements Filter {

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
			throws IOException, ServletException {

		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;

		String csp = "default-src 'self' https://*.momentive.com ;" + "frame-src 'self' https://*.momentive.com; "
				+ "report-uri 'self' https://*.momentive.com; "
				+ "script-src  'self' https://*.momentive.com 'unsafe-inline'; "
				+ "connect-src 'self' https://*.momentive.com; "
				+ "style-src  'self' https://*.momentive.com 'unsafe-inline'; "
				+ "worker-src  'none'; "
				+ "child-src  'none'; "
				+ "img-src 'self' https://*.momentive.com  data:; form-action 'self'; "
				+ "base-uri 'self' https://*.momentive.com; "
				+ "object-src 'none'; "
				+ "frame-ancestors 'self' https://*.momentive.com; block-all-mixed-content; ; ";
		
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("X-XSS-Protection", "1; mode=block");
		response.setHeader("Referrer-Policy", "no-referrer");
		response.setHeader("X-Content-Type-Options", "nosniff");
		response.setHeader("Permissions-Policy", "geolocation=(self \"https://*.momentive.com\"), microphone=()");
		response.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
		response.setHeader("X-Frame-Options", "SAMEORIGIN");
		response.setHeader("Content-Security-Policy", csp);
		response.setHeader("Set-Cookie", "JSESSIONID=" + request.getSession().getId() + ";HttpOnly; secure");
		// call next filter in the filter chain
		filterChain.doFilter(request, response);

	}

	@Override
	public void destroy() {

	}
}