package com.momentive.chemsherpa.util;

import java.io.UnsupportedEncodingException;
import java.util.Properties;

import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import com.momentive.chemsherpa.model.Mail;
import com.momentive.chemsherpa.model.Register;

public class SendMail {


	 private static final Properties  properties = new Properties();//.getInstance().getApplicationProperties();
     private static final String smtphost = properties.getProperty("listprice.mail.smtphost");
     private static final String globalfrom = properties.getProperty("listprice.email.global.from");
	
     public static void contactSupportTeam(Mail mail) {
	  	
	  Properties props = System.getProperties();
	  props.setProperty("mail.mime.charset", "UTF-8");
	  props.put("mail.smtp.host", smtphost);
	  String from  = mail.getFrom();
	  String cc = mail.getFrom();
      Session mailsession = Session.getDefaultInstance(props, null);
      String to = properties.getProperty("listprice.email.contactsupport.to");
     
      mailsession.setDebug(true);
      
      try {
       	  //creating new mime message
    	  MimeMessage msg = new MimeMessage(mailsession);
          //setting "from"
    	  if(from != null && from.trim().length() > 0) {
    		  msg.setFrom(new InternetAddress(from, "ChemSherpa Query"));
    	  }
    	  else {
    		  msg.setFrom(new InternetAddress(globalfrom, "ChemSherpa Query"));
    	  }
          //setting "to"
    	  msg.setRecipients(javax.mail.Message.RecipientType.TO, InternetAddress.parse(to, false));
    	  
    	  if(cc != null && cc.length() > 0) {
    		  msg.setRecipients(javax.mail.Message.RecipientType.CC, InternetAddress.parse(cc, false));
    	  }
    
       	  msg.setSubject(mail.getSubject(), "utf-8");
    	  MimeBodyPart mbp1 = new MimeBodyPart();
          mbp1.setText("E Mail received from Webuser id : "+mail.getUseremail() + " \n "+ mail.getContent());
                
          MimeMultipart mp = new MimeMultipart();
          mp.addBodyPart(mbp1);
          msg.setContent(mp);
          //Disabling email communication
          //Transport.send(msg);  
      }
      catch(MessagingException   | UnsupportedEncodingException ex) {
          ex.printStackTrace();
      }
       
	}
	

	public static void RegisterUserEmail(Register register) {
		
		 
	  Properties props = System.getProperties();
	  props.setProperty("mail.mime.charset", "UTF-8");
	  props.put("mail.smtp.host", smtphost);

      Session mailsession = Session.getDefaultInstance(props, null);
      String to = properties.getProperty("listprice.email.register.to");
     
    mailsession.setDebug(true);
      try {
       	  //creating new mime message
    	  MimeMessage msg = new MimeMessage(mailsession);
  
    	   msg.setFrom(new InternetAddress(globalfrom, "ListPrice-NewUser Registration"));
    	 
          //setting "to"
    	  msg.setRecipients(javax.mail.Message.RecipientType.TO, InternetAddress.parse(to, false));
    	  msg.setRecipients(javax.mail.Message.RecipientType.CC, InternetAddress.parse(globalfrom, false));
    	 
       	  msg.setSubject("New User Registration- ChemSherpa/Chemical Substances Application", "utf-8");
    	  MimeBodyPart mbp1 = new MimeBodyPart();
    	  
    	  String message = "Hello , \n Following user is registered to ChemSherpa/Chemical Substances application.Please check .\n\n\n"
    	  +"First Name: "+register.getFirstName()+"\n"
    	  +"Last Name : "+register.getLastName()+"\n"
    	  +"Email : "+register.getEmail()+"\n"
    	  +"Phone : "+register.getPhone()+"\n"
    	  +"Company : "+register.getCompanyName()+"\n"
    	  +"Thanks, \n Admin Team.\n";
          
    	  mbp1.setText(message);
          MimeMultipart mp = new MimeMultipart();
          mp.addBodyPart(mbp1);
          msg.setContent(mp);
          //Disabling email communication
         // Transport.send(msg);  
      }
      catch(MessagingException | UnsupportedEncodingException mex) {
          mex.printStackTrace();
      }
	}
	
	
	public static void sendpassword(String username, String passwd, String email) {
		
	  System.out.println("email sending :"+email);
	  Properties props = System.getProperties();
	  props.setProperty("mail.mime.charset", "UTF-8");
	  props.put("mail.smtp.host", smtphost);
	       Session mailsession = Session.getDefaultInstance(props, null);
      mailsession.setDebug(true);
      try {
       	  //creating new mime message
    	  MimeMessage msg = new MimeMessage(mailsession);
          //setting "from"
    	  msg.setFrom(new InternetAddress(globalfrom, "ChemSherpa/Chemical Substances  Application Password"));
          //setting "to"
    	  msg.setRecipients(javax.mail.Message.RecipientType.TO, 
        		  			InternetAddress.parse(email, false));
    	  
    	  
          //setting subject
    	  msg.setSubject("Momentive Pricing Application password");
    	  MimeBodyPart mbp1 = new MimeBodyPart();
          mbp1.setText("Hello,\n Your Momentive List Pricing Application username is : "+username+
        		  "\n Your  password is : "+passwd);
          /*MimeBodyPart mbp2 = new MimeBodyPart();
          if(mail.getAttach() != null) {
        	  FileDataSource fds = new FileDataSource(attachementsPath);
        	  mbp2.setDataHandler(new DataHandler(fds));
        	  mbp2.setFileName(fds.getName());
          }*/
          Multipart mp = new MimeMultipart();
          mp.addBodyPart(mbp1);
          //mp.addBodyPart(mail.getAttach());
 
          msg.setContent(mp);
          //sending the mail.
          System.out.println("ready to send now");
          //Disabling email communication
         // Transport.send(msg);  
      }
      catch(MessagingException | UnsupportedEncodingException mex) {
          mex.printStackTrace();
      }
	}
	
	
	public static void sendAddUserCommunicationEmail( String email) {
		
		  System.out.println("email sending :"+email);
		  Properties props = System.getProperties();
		  props.setProperty("mail.mime.charset", "UTF-8");
		  props.put("mail.smtp.host",smtphost);
		 
	      Session mailsession = Session.getDefaultInstance(props, null);
	    mailsession.setDebug(true);
	      try {
	       	  //creating new mime message
	    	  MimeMessage msg = new MimeMessage(mailsession);
	          //setting "from"
	    	  msg.setFrom(new InternetAddress(globalfrom, "Momentive ChemSherpa/Chemical Substances Application"));
	          //setting "to"
	    	  msg.setRecipients(javax.mail.Message.RecipientType.TO, 
	        		  			InternetAddress.parse(email, false));
	          //setting subject
	    	  msg.setSubject(properties.getProperty("listprice.communicate.user.subject"));
	    	  MimeBodyPart mbp1 = new MimeBodyPart();
	    	  String message = "Hello,\n You have been provided access to Momentive ChemSherpa/Chemical Substances application.";
	    	 // message+="\n\n Application URL : https://listprice.momentive.com/";
	    	  message+="\n\n if you have any queries, please feel free to send out a mail to Sales-JP.Silicones@momentive.com";
	    	  mbp1.setText(message);
	           
	          Multipart mp = new MimeMultipart();
	          mp.addBodyPart(mbp1);
	          
	          msg.setContent(mp);
	          //sending the mail.
	          System.out.println("ready to send now");
	          //Disabling email communication
	          //Transport.send(msg);  
	      }
	      catch(MessagingException | UnsupportedEncodingException mex) {
	          mex.printStackTrace();
	      }
	      
		}
	
	public static void sendActivateUserCommunicationEmail(String email) {
		
		  System.out.println("email sending :"+email);
		  Properties props = System.getProperties();
		  props.setProperty("mail.mime.charset", "UTF-8");
		  props.put("mail.smtp.host",smtphost);
		 
	      Session mailsession = Session.getDefaultInstance(props, null);
	    mailsession.setDebug(true);
	      try {
	       	  //creating new mime message
	    	  MimeMessage msg = new MimeMessage(mailsession);
	          //setting "from"
	    	  msg.setFrom(new InternetAddress(globalfrom, "Momentive ChemSherpa/Chemical Substances  Application"));
	          //setting "to"
	    	  msg.setRecipients(javax.mail.Message.RecipientType.TO, 
	        		  			InternetAddress.parse(email, false));
	          //setting subject
	    	  msg.setSubject(properties.getProperty("listprice.communicate.user.subject"));
	    	  MimeBodyPart mbp1 = new MimeBodyPart();
	    	  String message = "Hello,\n Your account has been activated to Momentive ChemSherpa/Chemical Substances application.Please find login details to access the application";
	    	  //message+="\n\n Application URL : https://listprice.momentive.com/";
	    	  message+="\n\n if you have any queries, please feel free to send out a mail to Sales-JP.Silicones@momentive.com";
	    	  mbp1.setText(message);
	           
	          Multipart mp = new MimeMultipart();
	          mp.addBodyPart(mbp1);
	          
	          msg.setContent(mp);
	          //sending the mail.
	          System.out.println("ready to send now");
	          //Disabling email communication
	          //Transport.send(msg);  
	      }
	      catch(MessagingException | UnsupportedEncodingException mex) {
	          mex.printStackTrace();
	      }
	      
		}
	
	
	public static void sendDocumentDetails(Mail mail) {
		
		  
		  Properties props = System.getProperties();
		  props.setProperty("mail.mime.charset", "UTF-8");
		  props.put("mail.smtp.host",smtphost);
		 
	      Session mailsession = Session.getDefaultInstance(props, null);
	    mailsession.setDebug(true);
	      try {
	       	  //creating new mime message
	    	  MimeMessage msg = new MimeMessage(mailsession);
	          //setting "from"
	    	  msg.setFrom(new InternetAddress(globalfrom, "Momentive ChemSherpa/Chemical Substances Application"));
	          //setting "to"
	    	  msg.setRecipients(javax.mail.Message.RecipientType.TO, 
	        		  			InternetAddress.parse(mail.getUseremail()));
	          //setting subject
	    	  msg.setSubject("Chemsherpa/Chemical Substance Document");
	    	  MimeBodyPart mbp1 = new MimeBodyPart();
	    	  String message = "Hello,\n You should be able to download the requested document from our website. ";
	    	 // message+="\n\n Application URL : https://listprice.momentive.com/";
	    	  message+="\n\n if you have any queries, please feel free to send out a mail to Sales-JP.Silicones@momentive.com";
	    	  mbp1.setText(message);
	           
	          Multipart mp = new MimeMultipart();
	          mp.addBodyPart(mbp1);
	          
	          msg.setContent(mp);
	          //sending the mail.
	          System.out.println("ready to send now");
	          //Disabling email communication
	          //Transport.send(msg);  
	      }
	      catch(MessagingException | UnsupportedEncodingException mex) {
	          mex.printStackTrace();
	      }
	      
		}
}