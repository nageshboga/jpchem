package com.momentive.chemsherpa.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Encrypt {

	public static void main(String[] args) {

		encrypt("Hello how are you");

	}


	public static void encrypt(String msg) {

		try {

	 		MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
	 		messageDigest.update(msg.getBytes());
	 		byte[] encryptedMessages = messageDigest.digest();
	 		System.out.println(encryptedMessages.toString());
	 		StringBuffer hexString = new StringBuffer();
	 	    for (int i = 0;i<encryptedMessages.length;i++) {
	 	    	hexString.append(Integer.toHexString(0xFF & encryptedMessages[i]));
	 	    }
	 	    System.out.println("Hex format : " + hexString.toString());  

		}
		catch(NoSuchAlgorithmException exception) {

			exception.printStackTrace();
		}
 	}
}