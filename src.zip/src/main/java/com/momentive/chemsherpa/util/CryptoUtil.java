package com.momentive.chemsherpa.util;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

public class CryptoUtil 
{

    private static Cipher ecipher, dcipher;
    // 8-byte Salt
    private static byte[] salt = {
        (byte) 0xA9, (byte) 0x9B, (byte) 0xC8, (byte) 0x32,
        (byte) 0x56, (byte) 0x35, (byte) 0xE3, (byte) 0x03
    };

    private static int iterationCount = 30;
    private static final String secretKey= "mpmjapanlistprice1419";
     

    public static String encrypt(String plainText)  {

    	String encryptedStr = "";
        
        try {
        	KeySpec keySpec = new PBEKeySpec(secretKey.toCharArray(), salt, iterationCount);

	        SecretKey key = SecretKeyFactory.getInstance("PBEWithMD5AndDES").generateSecret(keySpec);
	
	        AlgorithmParameterSpec paramSpec = new PBEParameterSpec(salt, iterationCount);
	
	        ecipher = Cipher.getInstance(key.getAlgorithm());
	        ecipher.init(Cipher.ENCRYPT_MODE, key, paramSpec);
	        String charSet = "UTF-8";
	        byte[] in = plainText.getBytes(charSet);
	        byte[] out = ecipher.doFinal(in);
	        encryptedStr = new String(Base64.getEncoder().encode(out));
	        
        }
        
        catch(InvalidKeySpecException  | NoSuchAlgorithmException | BadPaddingException | InvalidAlgorithmParameterException | 
        		InvalidKeyException | NoSuchPaddingException | UnsupportedEncodingException | IllegalBlockSizeException e ) {
        	e.printStackTrace();
        }
                
        return encryptedStr;
    }

 
    public static String decrypt(String encryptedText)  {

    	String decryptedStr= "";
    	
        try {
        	KeySpec keySpec = new PBEKeySpec(secretKey.toCharArray(), salt, iterationCount);
	        
	        SecretKey key = SecretKeyFactory.getInstance("PBEWithMD5AndDES").generateSecret(keySpec);
	
	        AlgorithmParameterSpec paramSpec = new PBEParameterSpec(salt, iterationCount);
	        dcipher = Cipher.getInstance(key.getAlgorithm());
	        dcipher.init(Cipher.DECRYPT_MODE, key, paramSpec);
	        byte[] enc = Base64.getDecoder().decode(encryptedText);
	        byte[] utf8 = dcipher.doFinal(enc);
	        String charSet = "UTF-8";
	        decryptedStr = new String(utf8, charSet);
        }
        
        catch(InvalidKeySpecException  | NoSuchAlgorithmException | BadPaddingException | InvalidAlgorithmParameterException | 
        		InvalidKeyException | NoSuchPaddingException | UnsupportedEncodingException | IllegalBlockSizeException e ) {
        	e.printStackTrace();
        }
        
        return decryptedStr;
    }    
    
    
//    public static void main(String[] args) throws Exception {
//    	
//        CryptoUtil cryptoUtil=new CryptoUtil();
//       
//        String plain="Pa55word";
//        String enc=cryptoUtil.encrypt(plain);
//
//        System.out.println("Original text: "+plain);
//        System.out.println("Encrypted text: "+enc);
//        String plainAfter=cryptoUtil.decrypt(enc);
//        System.out.println("Original text after decryption: "+plainAfter);
//    }
    
    
}