package com.momentive.chemsherpa.util;

import java.util.Random;

public class RandomPasswordGenerator {

    /**
     * This is a static method which will generate random password and returns the password as a string
     * 
     * @return String
     */
    public static String generateRandomPassword() {
        StringBuffer randomPassword = new StringBuffer(8);
        Random rn = new Random(System.currentTimeMillis());
        randomPassword.append(randNumberInRange(65, 90));// returns [A-Z]
        randomPassword.append(randNumberInRange(97, 122));// returns [a-z]
        randomPassword.append(randSpecialChar(rn));// returns [! @ ? % ^ & * < > _ $]
        randomPassword.append(randNumberInRange(65, 90));// returns [A-Z]
        randomPassword.append(randNumberInRange(97, 122));// returns [a-z]
        randomPassword.append(randNumberInRange(48, 57));// returns [0-9]
        randomPassword.append(randSpecialChar(rn));// returns [! @ ? % ^ & * < > _ $]
        randomPassword.append(randNumberInRange(48, 57));// returns [0-9]
        return randomPassword.toString();
    }

    /**
     * This method will take max and min value as input and returns random number and convert it to char between that
     * range that is sent as input and returns a single character string
     * 
     * @param min
     * @param max
     * @return String
     */
    public static String randNumberInRange(int min, int max) {
        int x = (int) (Math.random() * (max - min + 1)) + min;
        return String.valueOf((char) x);
    }

    /**
     * This method will return special characters read from application.properties and split them to form a string array
     * and pick randomly one special character
     * 
     * @param rn
     * @return String
     */
    public static String randSpecialChar(Random rn) {
        String[] specialCharactersArray = "! @ ? ^ & * _ $".split(" ");
        return specialCharactersArray[rn.nextInt(specialCharactersArray.length)].toString();
    }
}
