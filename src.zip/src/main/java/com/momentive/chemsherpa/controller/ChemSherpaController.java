package com.momentive.chemsherpa.controller;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.compress.utils.IOUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.momentive.chemsherpa.model.ChemSherpaSaleHistory;
import com.momentive.chemsherpa.model.Mail;
import com.momentive.chemsherpa.model.SearchChemSherpa;
import com.momentive.chemsherpa.model.UploadFile;
import com.momentive.chemsherpa.model.UsageReport;
import com.momentive.chemsherpa.model.User;
import com.momentive.chemsherpa.service.ChemSherpaService;
import com.momentive.chemsherpa.service.UserService;

@Controller
public class ChemSherpaController {

	private final String folder = "CHEMSHERPA_DOCS";

	@Autowired
	ChemSherpaService chemSherpaService;
	@Autowired
	UserService userService;
	

	@RequestMapping(value = "chemSHERPA")
	public ModelAndView getChemSherpaForCustomer(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute SearchChemSherpa searchChemSherpa) {

		ModelAndView mv = new ModelAndView("viewchemsherpa");
		User user = (User) request.getSession().getAttribute("user");
		if (user == null) {

			return UserController.sessiontimeoutpage(request, response);
		}
		mv.addObject("user", user);

		List<ChemSherpaSaleHistory> chemSherpaSaleHistories = chemSherpaService
				.getChemSherpaSaleHistory(user.getDistNumber());

		request.getSession().setAttribute("chemSherpaSaleHistories", chemSherpaSaleHistories);
		mv.addObject("chemSherpaSaleHistories", chemSherpaSaleHistories);
		
		 

		return mv;
	}

	@RequestMapping(value = "chemsubstances")
	public ModelAndView getChemicalSubstances(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute SearchChemSherpa searchChemSherpa) {

		ModelAndView mv = new ModelAndView("viewchemicalsubstances");
		User user = (User) request.getSession().getAttribute("user");
		if (user == null) {

			return UserController.sessiontimeoutpage(request, response);
		}
		mv.addObject("user", user);

		List<ChemSherpaSaleHistory> chemSubstancesSaleHistories = chemSherpaService
				.getChemSherpaSaleHistory(user.getDistNumber());

		request.getSession().setAttribute("chemSubstancesSaleHistories", chemSubstancesSaleHistories);
		mv.addObject("chemSubstancesSaleHistories", chemSubstancesSaleHistories);

		return mv;
	}

	@RequestMapping(value="searchchemsherpa")
	public ModelAndView searchChemSherpaForAdmin(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute SearchChemSherpa searchChemSherpa) {

		ModelAndView mv = new ModelAndView("viewchemsherpa");
		User user = (User) request.getSession().getAttribute("user");
		if (user == null) {

			return UserController.sessiontimeoutpage(request, response);
		}
		mv.addObject("user", user);

		List<ChemSherpaSaleHistory> chemSherpaSaleHistories = chemSherpaService
				.getChemSherpaSaleHistory(searchChemSherpa.getSearchDistNum());

		request.getSession().setAttribute("chemSherpaSaleHistories", chemSherpaSaleHistories);
		mv.addObject("chemSherpaSaleHistories", chemSherpaSaleHistories);

		return mv;
	}

	@RequestMapping(value = "searchchemsubstances")
	public ModelAndView searchChemSubstancesForAdmin(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute SearchChemSherpa searchChemSherpa) {

		ModelAndView mv = new ModelAndView("viewchemicalsubstances");
		User user = (User) request.getSession().getAttribute("user");
		if (user == null) {

			return UserController.sessiontimeoutpage(request, response);
		}
		mv.addObject("user", user);

		List<ChemSherpaSaleHistory> chemSubstancesSaleHistories = chemSherpaService
				.getChemSherpaSaleHistory(searchChemSherpa.getSearchDistNum());

		request.getSession().setAttribute("chemSubstancesSaleHistories", chemSubstancesSaleHistories);
		mv.addObject("chemSubstancesSaleHistories", chemSubstancesSaleHistories);

		return mv;
	}

	@RequestMapping(value = "downloadchemSHERPA")
	public void downloadChemSherpa(HttpServletRequest request, HttpServletResponse response) {

		String chemsherpamatnum = request.getParameter("chemsherpamatnum");
		String chemsherpamat = request.getParameter("chemsherpamat");
		String chemsherpatype = request.getParameter("chemsherpatype");
		User user = (User) request.getSession().getAttribute("user");
		if (user == null) {

			UserController.sessiontimeoutpage(request, response);
		}

		UsageReport report;

		String dirpath = "";
		String osname = System.getProperty("os.name").toUpperCase();

		dirpath = osname.contains("WINDOW") ? "C://" + folder : "/apps/" + folder;

		File file = new File(dirpath + "/" + chemsherpamatnum);

		response.setContentType("application/octet-stream");

		if (file.exists()) {

			report = new UsageReport();
			report.setMaterialNum(Integer.parseInt(chemsherpamat));
			report.setUserEmail(user.getEmail());
			report.setFileName(chemsherpamatnum);
			report.setMaterialType(chemsherpatype);
			chemSherpaService.saveChemSherpaUsageHistory(report);

			response.setHeader("Content-Disposition", "attachment;filename=" + chemsherpamatnum);
			try (FileInputStream in = new FileInputStream(file)) {

				ServletOutputStream out = response.getOutputStream();
				byte[] outputByte = new byte[4096];

				while (in.read(outputByte, 0, 4096) != -1) {
					out.write(outputByte, 0, 4096);
				}

				in.close();
				out.flush();
				out.close();
			}

			catch (IOException ioe) {
				ioe.printStackTrace();
			}
		} else {
			response.setHeader("Content-Disposition", "attachment;filename=file_not_exist.txt");
			try {

				ServletOutputStream out = response.getOutputStream();
				String msg = "chemSHERPA document not found for the material number : " + chemsherpamatnum
						+ " . Please contact sales-jp.silicones@momentive.com.";

				out.write(msg.getBytes());

				out.flush();
				out.close();

			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
		}
	}

	@GetMapping(value = "querychemsherpa")
	public ModelAndView openQueryWindow(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute SearchChemSherpa searchChemSherpa) {

		ModelAndView mv = new ModelAndView("viewchemsherpa");
		
		User user = (User) request.getSession().getAttribute("user");
		if (user == null) {
			return UserController.sessiontimeoutpage(request, response);
		}
		
		String matnum = request.getParameter("matnum");
		String matname = request.getParameter("matname");
		String subject = request.getParameter("subject");
		String message = request.getParameter("message");
		String type = request.getParameter("type");
		mv.addObject("message", "Your request has been submitted");
		Mail mail = new Mail();
		
		mail.setSubject(subject);
		mail.setContent(message);
		mail.setStatus("Open");
		mail.setType(type);
		
		userService.logEmailActivity(mail);
		System.out.println(matname + ":" + matname + ":" + subject + ":" + message);

		return mv;
	}

	@RequestMapping(value = "viewreports")
	public ModelAndView viewReports(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView mv = new ModelAndView("viewreports");
		User user = (User) request.getSession().getAttribute("user");
		if (user == null) {
			return UserController.sessiontimeoutpage(request, response);
		}

		List<UsageReport> reportList = chemSherpaService.getChemSherpaUsageHistory();
		request.getSession().setAttribute("reportList", reportList);
		mv.addObject("reportList", reportList);
		mv.addObject("user", user);
		return mv;
	}

	@RequestMapping(value = "viewuploaddocs")
	public ModelAndView viewUploadDocs(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute UploadFile uploadFile) {

		ModelAndView mv = new ModelAndView("uploaddocuments");
		User user = (User) request.getSession().getAttribute("user");
		if (user == null) {
			return UserController.sessiontimeoutpage(request, response);
		}
		mv.addObject("user", user);
		return mv;
	}

	@RequestMapping(value = "saveuploaddocs")
	public ModelAndView saveUploadDocs(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute UploadFile uploadFile) {

		ModelAndView mv = new ModelAndView("uploaddocuments");
		User user = (User) request.getSession().getAttribute("user");
		String status = "failure";
		if (user == null) {
			return UserController.sessiontimeoutpage(request, response);
		}

		MultipartFile schifile1 = uploadFile.getSchifile1();
		MultipartFile schifile2 = uploadFile.getSchifile2();

		if(schifile1!= null && schifile1.getSize() > 10485760 ) {
			mv.addObject("message", "label.docs.upload.maxsize");
			mv.addObject("user", user);
			status = "failure";
			mv.addObject("status", status);
			return mv;

		}
		
		if(schifile2!= null && schifile2.getSize() > 10485760 ) {
		
			mv.addObject("message", "label.docs.upload.maxsize");
			mv.addObject("user", user);
			status = "failure";
			mv.addObject("status", status);
			return mv;

		}
		
		String dirpath = "";
		String osname = System.getProperty("os.name").toUpperCase();

		dirpath = osname.contains("WINDOW") ? "C://" + folder + "/" : "/apps/" + folder + "/";

		if (schifile1 != null) {

			String fileName = schifile1.getOriginalFilename();
			// String fileExtension = fileName.substring(fileName.lastIndexOf("."));
			Path path = Paths.get(dirpath + fileName);

			try {
				Files.copy(schifile1.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
				status = "success";
			} catch (Exception e) {
				status = "failure";
				e.printStackTrace();
			}
		}
		if (schifile2 != null && !schifile2.getOriginalFilename().isEmpty()) {

			String fileName = schifile2.getOriginalFilename();
			// String fileExtension = fileName.substring(fileName.lastIndexOf("."));
			Path path = Paths.get(dirpath + fileName);

			try {
				Files.copy(schifile2.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
				status = "success";
			} catch (Exception e) {
				status = "failure";
				e.printStackTrace();
			}
		}

		chemSherpaService.saveUploadDocstoDB(uploadFile);

		mv.addObject("status", status);
		if (status.equalsIgnoreCase("success"))
			mv.addObject("message", "label.docs.upload.success");
		else
			mv.addObject("message", "label.docs.upload.error");
		mv.addObject("user", user);
		return mv;
	}

	@RequestMapping(value = "getmatdetails")
	public ModelAndView getMaterialData(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute UploadFile uploadFile) {

		ModelAndView mv = new ModelAndView("uploaddocuments");
		User user = (User) request.getSession().getAttribute("user");
		if (user == null) {

			return UserController.sessiontimeoutpage(request, response);
		}
		mv.addObject("user", user);
		String matNumber = uploadFile.getMatNumber();
		uploadFile = chemSherpaService.getMaterialDetails(matNumber);
		if (uploadFile == null) {

			uploadFile = new UploadFile();
			uploadFile.setMatNumber(matNumber);
		}
		mv.addObject("uploadFile", uploadFile);
		System.out.println(uploadFile.toString());
		return mv;
	}

	@RequestMapping(value = "downloadExcelusagereport")
	public void downloadExcelUsageReport(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute UploadFile uploadFile) {

		List<UsageReport> reportList = (List<UsageReport>) request.getSession().getAttribute("reportList");

		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=UsageReport.xlsx");

		ByteArrayInputStream stream = usageReportToExcelFile(reportList);

		try {
			IOUtils.copy(stream, response.getOutputStream());
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}

	}

	@RequestMapping(value = "downloadExcelchemsherpa")
	public void downloadExcelChemSherpaReport(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute UploadFile uploadFile) {

		List<ChemSherpaSaleHistory> chemSherpaSaleHistories = (List<ChemSherpaSaleHistory>) request.getSession()
				.getAttribute("chemSherpaSaleHistories");

		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=ChemSherpa.xlsx");

		ByteArrayInputStream stream = chemSherpaToExcelFile(chemSherpaSaleHistories);

		try {
			IOUtils.copy(stream, response.getOutputStream());
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}

	}

	@RequestMapping(value = "downloadExcelchemsubstances")
	public void downloadExcelChemSubstancesReport(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute UploadFile uploadFile) {

		List<ChemSherpaSaleHistory> chemSherpaSaleHistories = (List<ChemSherpaSaleHistory>) request.getSession()
				.getAttribute("chemSubstancesSaleHistories");

		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=ChemSubstances.xlsx");

		ByteArrayInputStream stream = chemSubstancesToExcelFile(chemSherpaSaleHistories);

		try {
			IOUtils.copy(stream, response.getOutputStream());
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}

	}

	private ByteArrayInputStream usageReportToExcelFile(List<UsageReport> usageReport) {

		try (Workbook workbook = new XSSFWorkbook()) {
			Sheet sheet = workbook.createSheet("UsageReport");

			Row row = sheet.createRow(0);
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFillForegroundColor(IndexedColors.LIGHT_ORANGE.getIndex());
			headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			// Creating header
			Cell cell = row.createCell(0);
			cell.setCellValue("User Name");
			cell.setCellStyle(headerCellStyle);

			cell = row.createCell(1);
			cell.setCellValue("Email");
			cell.setCellStyle(headerCellStyle);

			cell = row.createCell(2);
			cell.setCellValue("File Name");
			cell.setCellStyle(headerCellStyle);

			cell = row.createCell(3);
			cell.setCellValue("File Type");
			cell.setCellStyle(headerCellStyle);

			cell = row.createCell(4);
			cell.setCellValue("Time");
			cell.setCellStyle(headerCellStyle);

			cell = row.createCell(5);
			cell.setCellValue("Material Number");
			cell.setCellStyle(headerCellStyle);
			SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy, hh:mm:ss a");
			// Creating data rows for each customer
			for (int i = 0; i < usageReport.size(); i++) {

				Row dataRow = sheet.createRow(i + 1);
				dataRow.createCell(1).setCellValue(usageReport.get(i).getUserEmail());
				dataRow.createCell(2).setCellValue(usageReport.get(i).getFileName());
				dataRow.createCell(3).setCellValue(usageReport.get(i).getMaterialType());
				//System.out.println(sdf.format(usageReport.get(i).getUsageTime()));
				dataRow.createCell(4).setCellValue(sdf.format(usageReport.get(i).getUsageTime()));
				dataRow.createCell(5).setCellValue(usageReport.get(i).getMaterialNum());
			}

			// Making size of column auto resize to fit with data
			sheet.autoSizeColumn(0);
			sheet.autoSizeColumn(1);
			sheet.autoSizeColumn(2);
			sheet.autoSizeColumn(3);
			sheet.autoSizeColumn(4);
			sheet.autoSizeColumn(5);

			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			workbook.write(outputStream);
			return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	private ByteArrayInputStream chemSherpaToExcelFile(List<ChemSherpaSaleHistory> salesHist) {

		try (Workbook workbook = new XSSFWorkbook()) {
			Sheet sheet = workbook.createSheet("ChemSherpaReport");

			Row row = sheet.createRow(0);
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFillForegroundColor(IndexedColors.LIGHT_ORANGE.getIndex());
			headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			// Creating header
			Cell cell = row.createCell(0);
			cell.setCellValue("Material Number");
			cell.setCellStyle(headerCellStyle);

			cell = row.createCell(1);
			cell.setCellValue("Material Name");
			cell.setCellStyle(headerCellStyle);

			cell = row.createCell(2);
			cell.setCellValue("Material Type");
			cell.setCellStyle(headerCellStyle);

			cell = row.createCell(3);
			cell.setCellValue("Version");
			cell.setCellStyle(headerCellStyle);

			cell = row.createCell(4);
			cell.setCellValue("Documents");
			cell.setCellStyle(headerCellStyle);

			// Creating data rows for each customer
			for (int i = 0; i < salesHist.size(); i++) {

				Row dataRow = sheet.createRow(i + 1);
				dataRow.createCell(0).setCellValue(salesHist.get(i).getMatNumber());
				dataRow.createCell(1).setCellValue(salesHist.get(i).getMatName());
				dataRow.createCell(2).setCellValue(salesHist.get(i).getMatType());
				dataRow.createCell(3).setCellValue(salesHist.get(i).getVersion());
				dataRow.createCell(4)
						.setCellValue(salesHist.get(i).getSchifilename1() + (salesHist.get(i).getSchifilename2() != null
								? " , " + salesHist.get(i).getSchifilename2()
								: ""));
			}

			// Making size of column auto resize to fit with data
			sheet.autoSizeColumn(0);
			sheet.autoSizeColumn(1);
			sheet.autoSizeColumn(2);
			sheet.autoSizeColumn(3);
			sheet.autoSizeColumn(4);

			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			workbook.write(outputStream);
			return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	private ByteArrayInputStream chemSubstancesToExcelFile(List<ChemSherpaSaleHistory> salesHist) {

		try (Workbook workbook = new XSSFWorkbook()) {
			Sheet sheet = workbook.createSheet("ChemSubstancesReport");

			Row row = sheet.createRow(0);
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFillForegroundColor(IndexedColors.LIGHT_ORANGE.getIndex());
			headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			// Creating header
			Cell cell = row.createCell(0);
			cell.setCellValue("Material Number");
			cell.setCellStyle(headerCellStyle);

			cell = row.createCell(1);
			cell.setCellValue("Material Name");
			cell.setCellStyle(headerCellStyle);

			cell = row.createCell(2);
			cell.setCellValue("Material Type");
			cell.setCellStyle(headerCellStyle);

			cell = row.createCell(3);
			cell.setCellValue("Version");
			cell.setCellStyle(headerCellStyle);

			cell = row.createCell(4);
			cell.setCellValue("Documents");
			cell.setCellStyle(headerCellStyle);

			// Creating data rows for each customer
			for (int i = 0; i < salesHist.size(); i++) {

				Row dataRow = sheet.createRow(i + 1);
				dataRow.createCell(0).setCellValue(salesHist.get(i).getMatNumber());
				dataRow.createCell(1).setCellValue(salesHist.get(i).getMatName());
				dataRow.createCell(2).setCellValue(salesHist.get(i).getMatType());
				dataRow.createCell(3).setCellValue(salesHist.get(i).getVersion());
				dataRow.createCell(4)
						.setCellValue(salesHist.get(i).getSchifilename1() + salesHist.get(i).getSchifilename2() != null
								? " , " + salesHist.get(i).getSchifilename2()
								: "");
			}

			// Making size of column auto resize to fit with data
			sheet.autoSizeColumn(0);
			sheet.autoSizeColumn(1);
			sheet.autoSizeColumn(2);
			sheet.autoSizeColumn(3);
			sheet.autoSizeColumn(4);

			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			workbook.write(outputStream);
			return new ByteArrayInputStream(outputStream.toByteArray());
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

}
