package com.momentive.chemsherpa.controller;

import java.security.Principal;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.ModelAndView;

import com.momentive.chemsherpa.model.ChemSherpaSaleHistory;
import com.momentive.chemsherpa.model.LogActivity;
import com.momentive.chemsherpa.model.Mail;
import com.momentive.chemsherpa.model.SearchChemSherpa;
import com.momentive.chemsherpa.model.SearchUser;
import com.momentive.chemsherpa.model.User;
import com.momentive.chemsherpa.service.ChemSherpaService;
import com.momentive.chemsherpa.service.UserService;
import com.momentive.chemsherpa.util.SendMail;
import com.nimbusds.jose.shaded.json.JSONArray;

@Controller
public class UserController {

	@Autowired
	UserService userService;
	@Autowired
	ChemSherpaService chemSherpaService;
	@Autowired
	LocaleResolver localeResolver;
	
 
	@RequestMapping(value = "/")
	public ModelAndView azuressoauth(HttpServletRequest request, HttpServletResponse response,Principal principal) {	
		
		if(principal == null) {
			ModelAndView mv = new ModelAndView("ssologin");
			return mv;
		}
		
		OAuth2AuthenticationToken token = (OAuth2AuthenticationToken) principal;
		OAuth2User oAuth2User = token.getPrincipal();
 		Map<String,Object> attributes =  oAuth2User.getAttributes();
    	
		String firstName=  attributes.get("extension_FirstName")!= null ? (String) attributes.get("extension_FirstName") : null;
		String lastName=  attributes.get("extension_LastName")!= null ? (String) attributes.get("extension_LastName") : null;
		JSONArray emails =  attributes.get("emails")!= null ? (JSONArray)attributes.get("emails") : null;
	    String email =  emails.get(0) != null ? (String) emails.get(0) : "";
	    
 		User user = userService.validateUserwithAzureDetails(email.toString());

 		//route the user to register page.
 		if(user == null || user.getEmail() == null) {
 			
 			ModelAndView mv = new ModelAndView("registeruser");
 			user = new User();
 			user.setFirstName(firstName);
 			user.setLastName(lastName);
 			user.setEmail(email);
 		}
 		
 		//user is registered and status is not approved to access the application. 
 		if(user != null && user.getStatus() != 2) {
 			user = new User();
 			user.setFirstName(firstName);
 			user.setLastName(lastName);
 			user.setEmail(email);
 			
 			ModelAndView mv = new ModelAndView("ssologin");
 			mv.addObject("message", "error.account.verification.pending");
 			return mv;
 		}
 		
		if (user != null && user.getLangId() != null) {
			localeResolver.setLocale(request, response, new Locale(user.getLangId()));
		}

		String message = "";
		
		ModelAndView mv = new ModelAndView("viewchemsherpa");
		List<ChemSherpaSaleHistory> chemSherpaSaleHistories = chemSherpaService
				.getChemSherpaSaleHistory(user.getDistNumber());

		request.getSession().setAttribute("chemSherpaSaleHistories", chemSherpaSaleHistories);
		mv.addObject("chemSherpaSaleHistories", chemSherpaSaleHistories);
		mv.addObject("searchChemSherpa", new SearchChemSherpa());

		mv.addObject("user", user);
		request.getSession().setAttribute("user", user);
 		return mv;
	}
	
		
	@RequestMapping(value = "/chemsherpa")
	public ModelAndView azuressoauth2(HttpServletRequest request, HttpServletResponse response,Principal principal) {	
		
		if(principal == null) {
			ModelAndView mv = new ModelAndView("ssologin");
			return mv;
		}
		
		OAuth2AuthenticationToken token = (OAuth2AuthenticationToken) principal;
		OAuth2User oAuth2User = token.getPrincipal();
		Map<String,Object> attributes =  oAuth2User.getAttributes();
		
 		String email = attributes.get("preferred_username")!= null ? (String) attributes.get("preferred_username") : null;
 		String name = principal.getName() != null ? principal.getName() : null; 
 		String oid = attributes.get("oid")!= null ? (String) attributes.get("oid") : null; 
 
 		User user = userService.validateUserwithAzureDetails(email);

 		//route the user to register page.
 		if(user == null || user.getEmail() == null) {
 			
 		}
 		
 		//user is registered and status is not approved to access the application. 
 		if(user != null && user.getStatus() != 2) {
 			
 		}
 		
		if (user != null && user.getLangId() != null) {
			localeResolver.setLocale(request, response, new Locale(user.getLangId()));
		}

		String message = "";
		
		ModelAndView mv = new ModelAndView("viewchemsherpa");
		List<ChemSherpaSaleHistory> chemSherpaSaleHistories = chemSherpaService
				.getChemSherpaSaleHistory(user.getDistNumber());

		request.getSession().setAttribute("chemSherpaSaleHistories", chemSherpaSaleHistories);
		mv.addObject("chemSherpaSaleHistories", chemSherpaSaleHistories);
		mv.addObject("searchChemSherpa", new SearchChemSherpa());

		mv.addObject("user", user);
		request.getSession().setAttribute("user", user);
 		return mv;
	}
	
	
	@RequestMapping(value = "landingpage")
	public ModelAndView loginpage(HttpServletRequest request, HttpServletResponse response) {

		String lang = request.getParameter("lang");
		ModelAndView mv = new ModelAndView("ssologin");
		if (lang != null)
			localeResolver.setLocale(request, response, new Locale(lang));
	 
		return mv;
	}
	

	@RequestMapping(value = "logoutpage")
	public ModelAndView logoutpage(HttpServletRequest request, HttpServletResponse response ) {

		String lang = request.getParameter("lang");
		ModelAndView mv = new ModelAndView("ssologin");
		if (lang != null)
			localeResolver.setLocale(request, response, new Locale(lang));

		User user = (User) request.getSession().getAttribute("user");
		if (user == null) {
			return UserController.sessiontimeoutpage(request, response);
		}
		userService.updateLogoutActivity(user);
	 	request.getSession().invalidate();
		mv.addObject("message", "msg.logout.success");
		return mv;
	}
	 

	@RequestMapping(value = "homepage")
	public ModelAndView homepage(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView mv = new ModelAndView("home");
		User user = (User) request.getSession().getAttribute("user");
		if (user == null) {
			return UserController.sessiontimeoutpage(request, response);
		}

		if (request.getSession().getAttribute("materialList") != null) {
			mv.addObject("materialList", request.getSession().getAttribute("materialList"));
		}
		mv.addObject("user", user);
		return mv;
	}

	
	 
	@RequestMapping(value = "contactsupport")
	public ModelAndView contactSupport(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute Mail mail) throws Exception {

		ModelAndView mv = new ModelAndView("contactsupport");
		User user = (User) request.getSession().getAttribute("user");
		if (user == null) {
			return UserController.sessiontimeoutpage(request, response);
		}

		if (mail != null && mail.getClickedButton() != null && mail.getClickedButton().equalsIgnoreCase("sendmail")) {

//			mail.setSubject(new String(mail.getSubject().getBytes("ISO-8859-1"), "UTF-8"));
//			mail.setContent(new String(mail.getContent().getBytes("ISO-8859-1"), "UTF-8"));

			mail.setStatus("Open");
			mail.setType("Contact Support");
			mail.setFrom("nagesh.b@momentive.com");
			userService.logEmailActivity(mail);
			// SendMail.contactSupportTeam(mail);

			mv.addObject("message", "email.success");
			mv.addObject("status", "success");
		}
		mv.addObject("user", user);
		return mv;
	}

	@RequestMapping(value = "searchuser")
	public ModelAndView searchUser(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("searchUser") SearchUser searchUser) throws Exception {

		ModelAndView mv = new ModelAndView("searchuser");
		User user = (User) request.getSession().getAttribute("user");
		if (user == null) {
			return UserController.sessiontimeoutpage(request, response);
		}

		if (searchUser != null && searchUser.getSearchBy() != null && searchUser.getSearchValue() != null) {

			// searchUser.setSearchValue(new
			// String(searchUser.getSearchValue().getBytes("ISO-8859-1"), "UTF-8"));

			List<SearchUser> searchUsersList = userService.searchUsers(searchUser);
			mv.addObject("searchUsersList", searchUsersList);
			request.getSession().setAttribute("searchUsersList", searchUsersList);
		}

		mv.addObject("user", user);

		return mv;
	}

	@RequestMapping(value = "getsearchuserdetails")
	public ModelAndView getSearchUserDetails(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("searchUser") SearchUser searchUser) {

		ModelAndView mv = new ModelAndView("searchuserdetails");
		User user = (User) request.getSession().getAttribute("user");

		if (user == null) {
			return UserController.sessiontimeoutpage(request, response);
		}
		String clickedUser = searchUser.getClickedId();
		if (clickedUser != null && clickedUser.trim().length() > 0) {
			List<SearchUser> searchUsersList = (List<SearchUser>) request.getSession().getAttribute("searchUsersList");
			searchUser = userService.getsearchUserDetails(clickedUser);
			List<LogActivity> logActivity = userService.searchUserLogActivity(clickedUser);
			mv.addObject("logActivity", logActivity);
		}
		mv.addObject("user", user);
		mv.addObject("searchUser", searchUser);
		return mv;
	}

	@RequestMapping(value = "updatesearchuserdetails")
	public ModelAndView updateSearchUserDetails(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("searchUser") SearchUser searchUser) throws Exception {

		ModelAndView mv = new ModelAndView("searchuserdetails");
		User user = (User) request.getSession().getAttribute("user");
		String message = "";
		if (user == null) {
			return UserController.sessiontimeoutpage(request, response);
		}

		if (userService.updateSearchUser(searchUser)) {

			message = "profile.user.update.success";
			if (searchUser.isCommunicateToUser()) {
				SendMail.sendActivateUserCommunicationEmail( searchUser.getSearchUserEmail());
			}

		} else {
			message = "profile.user.update.failure";
		}
		searchUser = userService.getsearchUserDetails(searchUser.getSearchUserEmail());
		List<LogActivity> logActivity = userService.searchUserLogActivity(searchUser.getSearchUserEmail());
		mv.addObject("logActivity", logActivity);

		mv.addObject("message", message);
		mv.addObject("user", user);
		mv.addObject("searchUser", searchUser);
		return mv;
	}

	@RequestMapping(value = "myprofile")
	public ModelAndView myProfile(HttpServletRequest request, HttpServletResponse response, @ModelAttribute User user)
			throws Exception {

		ModelAndView mv = new ModelAndView("myprofile");
		User sessionUser = (User) request.getSession().getAttribute("user");

		if (sessionUser == null) {
			return UserController.sessiontimeoutpage(request, response);
		}
		user.setUserSeq(sessionUser.getUserSeq());
		if (user.getClickedButton() != null && user.getClickedButton().equals("updateuser")) {

			if (userService.updateUser(user)) {
				
				sessionUser.setFirstName(user.getFirstName());
				sessionUser.setLastName(user.getLastName());
				sessionUser.setEmail(user.getEmail());
				sessionUser.setLangId(user.getLangId());
				sessionUser.setCompany(user.getCompany());
				sessionUser.setPhone(user.getPhone());
				sessionUser.setDistNumber(user.getDistNumber());
				sessionUser.setLastUpdatedProfile(new java.util.Date());
				request.getSession().setAttribute("user", sessionUser);

				if (sessionUser != null && sessionUser.getLangId() != null) {
					localeResolver.setLocale(request, response, new Locale(sessionUser.getLangId()));
				}
				mv.addObject("status", "success");
				mv.addObject("message", "profile.update.success");

			} else {
				mv.addObject("message", "profile.update.failure");
				mv.addObject("status", "failed");
			}
		} else {
			user = sessionUser;
		}

		mv.addObject("user", sessionUser);
		return mv;
	}

	@RequestMapping(value = "addnewuser")
	public ModelAndView addNewUser(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute SearchUser searchUser) throws Exception {

		ModelAndView mv = new ModelAndView("addnewuser");
		User user = (User) request.getSession().getAttribute("user");
		if (user == null) {
			return UserController.sessiontimeoutpage(request, response);
		}

		if (searchUser.getClickedButton() != null && searchUser.getClickedButton().equalsIgnoreCase("addnewuser")) {

//			searchUser.setSearchUserFirstName(
//					new String(searchUser.getSearchUserFirstName().getBytes("ISO-8859-1"), "UTF-8"));
//			searchUser.setSearchUserLastName(
//					new String(searchUser.getSearchUserLastName().getBytes("ISO-8859-1"), "UTF-8"));
//			searchUser.setSearchUserEmail(new String(searchUser.getSearchUserEmail().getBytes("ISO-8859-1"), "UTF-8"));
//			searchUser.setSearchUserCompany(
//					new String(searchUser.getSearchUserCompany().getBytes("ISO-8859-1"), "UTF-8"));

			if (!userService.checkUserNameExistince(searchUser.getSearchUserEmail())) {
				userService.addUser(searchUser);
				mv.addObject("message", "adduser.success");
				mv.addObject("status", "success");

				if (searchUser.isCommunicateToUser()) {

					SendMail.sendAddUserCommunicationEmail(searchUser.getSearchUserEmail());
				}
			} else {
				mv.addObject("status", "failed");
				mv.addObject("message", "registeruser.useralreadyexists");
			}
		}
		mv.addObject("searchuser", searchUser);
		mv.addObject("user", user);
		return mv;
	}

	@RequestMapping(value = "viewemails")
	public ModelAndView viewEmails(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute Mail mail) {

		ModelAndView mv = new ModelAndView("viewemails");
		User user = (User) request.getSession().getAttribute("user");
		if (user == null) {
			return UserController.sessiontimeoutpage(request, response);
		}

		List<Mail> mailsList = userService.getRequestList();
		mv.addObject("mailsList", mailsList);
		mv.addObject("user", user);
		return mv;
	}

	@RequestMapping(value = "getrequestdetail")
	public ModelAndView getRequest(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute Mail mail) {

		ModelAndView mv = new ModelAndView("viewrequest");
		User user = (User) request.getSession().getAttribute("user");
		if (user == null) {
			return UserController.sessiontimeoutpage(request, response);
		}

		mail = userService.getRequestDetails(mail.getMailSeqId() + "");
		mv.addObject("user", user);
		mv.addObject("mail", mail);
		return mv;
	}

	@RequestMapping(value = "saverequestdetail")
	public ModelAndView updateRequest(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute Mail mail) {

		ModelAndView mv = new ModelAndView("viewrequest");
		User user = (User) request.getSession().getAttribute("user");
		if (user == null) {
			return UserController.sessiontimeoutpage(request, response);
		}
		userService.updateRequestDetails(mail);

		mv.addObject("message", "label.request.success");
		mv.addObject("status", "success");

		if (mail.isCommunicateToUser()) {

			//SendMail.sendDocumentDetails(mail);
		}

		mv.addObject("user", user);
		return mv;
	}

	public static ModelAndView sessiontimeoutpage(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView mv = new ModelAndView("ssologin");
		mv.addObject("message", "msg.session.timeout");
		return mv;
	}
}