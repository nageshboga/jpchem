package com.momentive.chemsherpa.controller;

public class Test {

	public static void main(String[] args) {

		int i =6;
		switch(i) {
		case 1:
			System.out.println("sunday"); break;
		case 2:
			System.out.println("monday");break;
		case 3:
			System.out.println("tuesday");break;
		case 4:
			System.out.println("wednesday");break;
		case 5:
			System.out.println("thursday");break;
		case 6:
			System.out.println("friday");break;
		case 7:
			System.out.println("saturday");break;
		}
		 
		//System.out.println(k);
//		for (int i = 1; i < 10000; i++) {
//			System.out.println("Hello "+s);
//			
////			System.out.println("Table for :"+ i);
////
////			for(int j=1; j<=10; j++) {
////				
////				System.out.println(i +" X "+j +" = " + i*j);
////			}
////			System.out.println("==========================================");
//		}

	}

}